<?php

// Function to check if 24 hours have passed
function is24HoursPassed($lastUpdatedTimestamp) {
    $currentTime = time();
    return ($currentTime - $lastUpdatedTimestamp) >= 24 * 60 * 60;
}

// Function to select one task randomly from each test
function selectTasks() {
    // Define tasks for each test
    $test1Tasks = [
        ["title" => "Test 1 Task 1", "description" => "Description of Test 1 Task 1"],
        ["title" => "Test 1 Task 2", "description" => "Description of Test 1 Task 2"],
        ["title" => "Test 1 Task 3", "description" => "Description of Test 1 Task 3"],
        ["title" => "Test 1 Task 4", "description" => "Description of Test 1 Task 4"],
        ["title" => "Test 1 Task 5", "description" => "Description of Test 1 Task 5"],
        ["title" => "Test 1 Task 6", "description" => "Description of Test 1 Task 6"],
        ["title" => "Test 1 Task 7", "description" => "Description of Test 1 Task 7"],
        ["title" => "Test 1 Task 8", "description" => "Description of Test 1 Task 8"],
        ["title" => "Test 1 Task 9", "description" => "Description of Test 1 Task 9"],
        // Add more tasks for Test 1...
        ["title" => "Test 1 Task 10", "description" => "Description of Test 1 Task 10"]
    ];
    
    $test2Tasks = [
        ["title" => "Test 2 Task 1", "description" => "Description of Test 2 Task 1"],
        ["title" => "Test 2 Task 2", "description" => "Description of Test 2 Task 2"],
        ["title" => "Test 2 Task 3", "description" => "Description of Test 2 Task 3"],
        ["title" => "Test 2 Task 4", "description" => "Description of Test 2 Task 4"],
        ["title" => "Test 2 Task 5", "description" => "Description of Test 2 Task 5"],
        ["title" => "Test 2 Task 6", "description" => "Description of Test 2 Task 6"],
        ["title" => "Test 2 Task 7", "description" => "Description of Test 2 Task 7"],
        ["title" => "Test 2 Task 8", "description" => "Description of Test 2 Task 8"],
        ["title" => "Test 2 Task 9", "description" => "Description of Test 2 Task 9"],
        // Add more tasks for Test 2...
        ["title" => "Test 2 Task 10", "description" => "Description of Test 2 Task 10"]
    ];
    
    $test2Tasks = [
        ["title" => "Test 2 Task 1", "description" => "Description of Test 2 Task 1"],
        ["title" => "Test 2 Task 2", "description" => "Description of Test 2 Task 2"],
        ["title" => "Test 2 Task 3", "description" => "Description of Test 2 Task 3"],
        ["title" => "Test 2 Task 4", "description" => "Description of Test 2 Task 4"],
        ["title" => "Test 2 Task 5", "description" => "Description of Test 2 Task 5"],
        ["title" => "Test 2 Task 6", "description" => "Description of Test 2 Task 6"],
        ["title" => "Test 2 Task 7", "description" => "Description of Test 2 Task 7"],
        ["title" => "Test 2 Task 8", "description" => "Description of Test 2 Task 8"],
        ["title" => "Test 2 Task 9", "description" => "Description of Test 2 Task 9"],
        // Add more tasks for Test 2...
        ["title" => "Test 2 Task 10", "description" => "Description of Test 2 Task 10"]
    ];
    
    $test3Tasks = [
        ["title" => "Test 3 Task 1", "description" => "Description of Test 2 Task 1"],
        ["title" => "Test 3 Task 2", "description" => "Description of Test 2 Task 2"],
        ["title" => "Test 3 Task 3", "description" => "Description of Test 2 Task 3"],
        ["title" => "Test 3 Task 4", "description" => "Description of Test 2 Task 4"],
        ["title" => "Test 3 Task 5", "description" => "Description of Test 2 Task 5"],
        ["title" => "Test 3 Task 6", "description" => "Description of Test 2 Task 6"],
        ["title" => "Test 3 Task 7", "description" => "Description of Test 2 Task 7"],
        ["title" => "Test 3 Task 8", "description" => "Description of Test 2 Task 8"],
        ["title" => "Test 3 Task 9", "description" => "Description of Test 2 Task 9"],
        // Add more tasks for Test 2...
        ["title" => "Test 3 Task 10", "description" => "Description of Test 2 Task 10"]
    ];
    
    $test4Tasks = [
        ["title" => "Test 4 Task 1", "description" => "Description of Test 2 Task 1"],
        ["title" => "Test 4 Task 2", "description" => "Description of Test 2 Task 2"],
        ["title" => "Test 4 Task 3", "description" => "Description of Test 2 Task 3"],
        ["title" => "Test 4 Task 4", "description" => "Description of Test 2 Task 4"],
        ["title" => "Test 4 Task 5", "description" => "Description of Test 2 Task 5"],
        ["title" => "Test 4 Task 6", "description" => "Description of Test 2 Task 6"],
        ["title" => "Test 4 Task 7", "description" => "Description of Test 2 Task 7"],
        ["title" => "Test 4 Task 8", "description" => "Description of Test 2 Task 8"],
        ["title" => "Test 4 Task 9", "description" => "Description of Test 2 Task 9"],
        // Add more tasks for Test 2...
        ["title" => "Test 4 Task 10", "description" => "Description of Test 2 Task 10"]
    ];
    
    $test5Tasks = [
        ["title" => "Test 5 Task 1", "description" => "Description of Test 2 Task 1"],
        ["title" => "Test 5 Task 2", "description" => "Description of Test 2 Task 2"],
        ["title" => "Test 5 Task 3", "description" => "Description of Test 2 Task 3"],
        ["title" => "Test 5 Task 4", "description" => "Description of Test 2 Task 4"],
        ["title" => "Test 5 Task 5", "description" => "Description of Test 2 Task 5"],
        ["title" => "Test 5 Task 6", "description" => "Description of Test 2 Task 6"],
        ["title" => "Test 5 Task 7", "description" => "Description of Test 2 Task 7"],
        ["title" => "Test 5 Task 8", "description" => "Description of Test 2 Task 8"],
        ["title" => "Test 5 Task 9", "description" => "Description of Test 2 Task 9"],
        // Add more tasks for Test 2...
        ["title" => "Test 2 Task 10", "description" => "Description of Test 2 Task 10"]
    ];
    // Add more test tasks arrays as needed...

    // Select one task randomly from each test
    $selectedTasks = [];

    $selectedTasks[] = $test1Tasks[array_rand($test1Tasks)];
    $selectedTasks[] = $test2Tasks[array_rand($test2Tasks)];
    $selectedTasks[] = $test3Tasks[array_rand($test3Tasks)];
    $selectedTasks[] = $test4Tasks[array_rand($test4Tasks)];
    $selectedTasks[] = $test5Tasks[array_rand($test5Tasks)];
    // Add more selected tasks for other tests as needed...

    return $selectedTasks;
}

// Check if tasks need to be updated
if (!isset($_SESSION['tasks']) || !isset($_SESSION['lastUpdated']) || is24HoursPassed($_SESSION['lastUpdated'])) {
    // Generate new tasks
    $_SESSION['tasks'] = selectTasks();
    $_SESSION['lastUpdated'] = time();
}

// Return selected tasks data as JSON
header('Content-Type: application/json');
echo json_encode($_SESSION['tasks']);
?>
