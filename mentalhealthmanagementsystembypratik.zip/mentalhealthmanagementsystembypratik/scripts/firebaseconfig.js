import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signInWithPopup, GoogleAuthProvider } from "firebase/auth";

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDXoYiKAhNVwqz8xgfSoK9ryp_y7Wm8sH8",
  authDomain: "chi-square-f9c32.firebaseapp.com",
  projectId: "chi-square-f9c32",
  storageBucket: "chi-square-f9c32.appspot.com",
  messagingSenderId: "577092644944",
  appId: "1:577092644944:web:6e96416bcf73227c02e155",
  measurementId: "G-VE4ZVWKW3P"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
export const database = getFirestore(app);
export const storage = getStorage(app);

//functions
function login(email, password) {
  const auth = getAuth();
  signInWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
      // User logged in successfully
      console.log(userCredential.user);
    })
    .catch((error) => {
      alert(error);
    });
}

function signUp(email, password) {
  const auth = getAuth();
  createUserWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
      // User signed up successfully
      console.log(userCredential.user);
    })
    .catch((error) => {
      alert(error);
    });
}

function signInPopup(){
  const auth = getAuth();
  const gooleProvider = new GoogleAuthProvider;
  signInWithPopup(auth, gooleProvider)
  .then((userCredential) => {
    // User signed up successfully
    console.log(userCredential.user);
  })
  .catch((error) => {
    alert(error);
  });
}

let btn = document.getElementById("submit") 
btn.addEventListener("click", () => {
    console.log("Hello there");
});
