function signup(){
    location.href = "signup.html"
}