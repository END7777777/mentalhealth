function signup(){
    location.href = "getstarted.html"
}

function learnMore(){
    let logInData = JSON.parse(localStorage.getItem("login"));
    if (logInData){
        alert("Coming Soon")
    }else{
        location.href = "getstarted.html"
    }
}


