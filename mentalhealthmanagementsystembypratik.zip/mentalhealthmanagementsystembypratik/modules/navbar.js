function navbar(){
    return `
    <div class="logo">
        <a href="index.html"><img id= "logo_img" src="assets/logo.png" alt=""></a>
        </div>
        <div>
        <div id="navbarLinksSet">
        <div class="nav_links" id="howItWorks">Mindfullness Activities<i class="fa-solid fa-chevron-down"></i>
        </div>
        <div class="nav_links" id="employers">
        </div>
        <div class="nav_links" id="forFamilies">
            Surveys <i class="fa-solid fa-chevron-down"></i>
        </div>
        <div class="nav_links" id="careers">
        Mental Health Services  <i class="fa-solid fa-chevron-down"></i>
        </div>
        </div>
        <div id="nav_end">
    
            <button id="signupBtn">Log out</button>        
        </div>
        </div>`
}

function navbarMediaQurrMedium(){
    return `<div id="uponMedmScreen">
    <div id="mdmScreenNavImg">
        <img src="assets/logo.png" alt="">
    </div>
    <div id="menuBar">
        <i class="fa-solid fa-bars"></i>
    </div>
    </div>`
}

export {navbar};

/* <a href=""><i class="fa-solid fa-bars"></i></a> */